import React, {Component} from 'react';

class Favourite extends Component {
    render() {
        return (
            <div>
                Favourite
            </div>
        );
    }
}

export default Favourite;