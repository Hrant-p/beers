export const beerAPI = 'https://api.punkapi.com/v2/beers';
